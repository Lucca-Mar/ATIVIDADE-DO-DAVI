/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
public class Media
{
	public static void main(String[] args) {
		float nota1 = 9;
		float nota2 = 2;
		 float media;
		 
		 media = (nota1 + nota2)/ ;
		 System.out.println("A média das notas é:" + media);
	}
}
