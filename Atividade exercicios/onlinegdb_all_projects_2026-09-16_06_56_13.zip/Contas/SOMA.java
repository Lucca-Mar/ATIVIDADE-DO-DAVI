/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
public class SOMA
{
	public static void main(String[] args) {
		int numero1 = 12;
		int numero2 = 10;
		int resultado;
		
		resultado = numero1 + numero2;
		System.out.println("O resultado da sua subtração é :" + resultado);
		
		resultado = numero1 - numero2;
		System.out.println("O resultado da sua subtração é :" + resultado);
		
		resultado = numero1 * numero2; 
		System.out.println("O resultado da sua multiplicação é :" + resultado);
		
		resultado = numero1 / numero2;
		System.out.println("O resultado da sua divisão é :" + resultado);
	}
}
