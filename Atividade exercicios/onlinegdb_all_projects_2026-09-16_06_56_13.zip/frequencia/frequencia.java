/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
public class frequencia
{
	public static void main(String[] args) {
	float aulas = 120;
	float frequentadas = 84;
	float resultado; 
	
	resultado = (frequentadas / aulas) * 100;  
	System.out.println("Sua frequencia é de:" + resultado );
	}
}
