/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
public class Salario
{
	public static void main(String[] args) {
	int salarioph = 15 ;
	int horast = 8;
	int bruto;
	
	bruto = salarioph * horast;
	System.out.println("Seu salário é de:" + bruto);
	
	}
}
